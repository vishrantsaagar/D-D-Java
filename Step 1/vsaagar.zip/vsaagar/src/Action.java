package src;

public class Action {
      
    public void setMessage(String msg) 
   {
    System.out.println("Action: msg" + msg);
   }

   public void setIntValue(int v)
   {
    System.out.println("Action:v" + v);
   }

   public void setCharValue(char c)
   {
    System.out.println("Action:c" + c);
   }
}
