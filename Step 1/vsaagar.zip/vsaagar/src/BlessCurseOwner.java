package src;

public class BlessCurseOwner extends ItemAction{
    
    public BlessCurseOwner(Item owner){
        super(owner);
        System.out.println("BlessCurseOwner");
    }
}
