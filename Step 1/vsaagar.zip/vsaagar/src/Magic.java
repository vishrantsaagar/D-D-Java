package src;

public class Magic extends Displayable{

}
