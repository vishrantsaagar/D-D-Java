package src;

public class CreatureAction extends Action{

    public CreatureAction(Creature owner)
    {
        System.out.println("CreatureAction:CreationAction");
    }
}
