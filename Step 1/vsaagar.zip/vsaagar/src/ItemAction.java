package src;

public class ItemAction extends Action{
    
    public ItemAction(Item owner)
    {
        System.out.println("ItemAction");
    }
}
