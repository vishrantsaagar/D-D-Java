package src;

public class ObjectDisplayGrid {
   
    public static void getObjectDisplayGrid(int gameHeight, int width, int topHeight, int bottomHeight)
    {
        System.out.println("ObjectDisplayGrid: getObjectDisplayGrid" + gameHeight + "\n" + width + "\n" + topHeight + "\n" + bottomHeight);
    }

    public void setTopMessageHeight(int topHeight){
        System.out.println("ObjectDisplayGrid: setTopMessageHeight" + topHeight);
    }
}
