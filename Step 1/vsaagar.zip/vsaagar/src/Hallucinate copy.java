package src;

public class Hallucinate extends ItemAction{
   
    Hallucinate(Item owner){
        super(owner);
        System.out.println("Hallucinate");

    }
}
